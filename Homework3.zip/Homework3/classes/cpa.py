# cpa class which connects database to the terminals when getting or adding new data
from backend import connection, database


class Cpa(object):

    def __init__(self, cpa_id, cpa_name, cpa_assistant, cpa_check):
        self.id = cpa_id
        self.name = cpa_name
        self.assistant = cpa_assistant
        self.cpa_check = cpa_check

# save function
    def save(self):
        with connection.get_connection() as conn:
            new_cpa_data = database.add_cpa(conn, self.name, self.assistant, self.cpa_check)
            self.id = new_cpa_data

# modifying functions
    @classmethod
    def add_cpa(cls, name, assistant, cpa_check):
        new_cpa_instance = cls(cpa_id=None, cpa_name=name, cpa_assistant=assistant, cpa_check=cpa_check)
        return new_cpa_instance

    def update_cpa(self, name=None, assistant=None):
        if name:
            self.name = name
        if assistant:
            self.assistant = assistant

        with connection.get_connection() as conn:
            database.update_cpa(conn, self.name, self.assistant, self.id)
        self.save()

    def update_check(self, cpa_check=None):
        if cpa_check:
            self.cpa_check = cpa_check

        with connection.get_connection() as conn:
            database.update_cpa_check(conn, self.cpa_check)
            self.save()

# getter functions
    @classmethod
    def get_cpa_by_id(cls, cpa_id):
        with connection.get_connection() as conn:
            cpa_data = database.select_cpa(conn, cpa_id)
            if cpa_data:
                cpa_instance = cls(cpa_id, *cpa_data)
                return cpa_instance
            else:
                return None

    @classmethod
    def get_all_cpa(cls):
        with connection.get_connection() as conn:
            cpa_data = database.view_cpa_list(conn)
            if cpa_data:
                print(len(cpa_data))
                client_instance = [cls(cpa[0], cpa[1], cpa[2], cpa[3]) for cpa in cpa_data]
                return client_instance
            else:
                return None

# print statement for cpa functions
    def __repr__(self):
        return (f" CPA ID: {self.id!r} CPA Name: {self.name!r}, CPA Assistant: {self.assistant!r}, "
                f"CPA tax check: {self.cpa_check}")
