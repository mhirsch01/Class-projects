# Client class which connects database to the terminals when getting or adding new data
from backend import connection, database


class Client(object):

    def __init__(self, client_id, first_name, last_name, address, income, tax_material, tax_filled, filling_timestamp,
                 cpa):
        self.id = client_id
        self.first_name = first_name
        self.last_name = last_name
        self.address = address
        self.income = income
        self.tax_material = tax_material
        self.tax_filled = tax_filled
        self.filling_timestamp = filling_timestamp
        self.cpa = cpa

# save function
    def save(self):
        with connection.get_connection() as conn:
            new_client_data = database.add_client(conn, self.first_name, self.last_name, self.address, self.income,
                                                  self.tax_material,  self.tax_filled, self.filling_timestamp, self.cpa)
            self.id = new_client_data

# modifying functions
    @classmethod
    def add_client(cls, first_name, last_name, address, income, tax_material, tax_filled, filling_timestamp, cpa):
        with connection.get_connection() as conn:
            new_client_instance = cls(conn, first_name=first_name, last_name=last_name, address=address, income=income,
                                      tax_material=tax_material, tax_filled=tax_filled,
                                      filling_timestamp=filling_timestamp, cpa=cpa)
            return new_client_instance

    def update_client(self, first_name=None, last_name=None, address=None, income=None, tax_material=None,
                      tax_filled=None, filling_timestamp=None, cpa=None):
        if first_name:
            self.first_name = first_name
        if last_name:
            self.last_name = last_name
        if address:
            self.address = address
        if income:
            self.income = income
        if tax_material:
            self.tax_material = tax_material
        if tax_filled:
            self.tax_filled = tax_filled
        if filling_timestamp:
            self.filling_timestamp = filling_timestamp
        if cpa:
            self.cpa = cpa

        with connection.get_connection() as conn:
            database.update_client(conn, self.first_name, self.last_name, self.address, self.income, self.tax_material,
                                   self.tax_filled, self.filling_timestamp, self.cpa, self.id)
        self.save()

# getter functions
    @classmethod
    def get_missing_tax_material(cls):
        with connection.get_connection() as conn:
            client_data = database.get_missing_tax_material(conn)
            if client_data:
                if client_data:
                    client_instance = [cls(client[0], client[1], client[2], client[3], client[7],
                                           client[4], client[5], client[8], client[6]) for client in client_data]
                    return client_instance
                else:
                    return None

    @classmethod
    def get_client_by_id(cls, client_id):
        with connection.get_connection() as conn:
            client_data = database.select_client(conn, client_id)
            if client_data:
                client_instance = cls(client_id, *client_data)
                return client_instance
            else:
                return None

    @classmethod
    def get_all_clients(cls):
        with connection.get_connection() as conn:
            client_data = database.view_client_list(conn)
            if client_data:
                client_instance = [cls(client[0], client[1], client[2], client[3], client[7],
                                       client[4], client[5], client[8], client[6]) for client in client_data]
                return client_instance
            else:
                return None

# print statement for client functions
    def __repr__(self):
        return (f" Client ID: {self.id!r} Client name: {self.first_name!r} {self.last_name!r} Address: {self.address!r}"
                f" Income: {self.income!r} Tax material:{self.tax_material} Tax Filled: {self.tax_filled!r}"
                f" Time Filled: {self.filling_timestamp!r} CPA: {self.cpa!r}")
