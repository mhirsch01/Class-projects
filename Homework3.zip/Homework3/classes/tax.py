# Tax class which connects database to the terminals when getting or adding new data
from backend import connection, database


class Tax(object):

    def __init__(self, client_id, client_first_name, client_last_name, client_tax_filled, filling_timestamp, cpa):
        self.client_id = client_id
        self.client_first_name = client_first_name
        self.client_last_name = client_last_name
        self.client_tax_filled = client_tax_filled
        self.filling_timestamp = filling_timestamp
        self.cpa = cpa

# getter functions
    @classmethod
    def get_client_tax_by_(cls, client_id):
        with connection.get_connection() as conn:
            tax_data = database.select_tax(conn, client_id)
        if tax_data:
            tax_instance = cls(client_id, tax_data[1], tax_data[2], tax_data[3], tax_data[4], tax_data[0])
            return tax_instance
        else:
            return None

# print statement for tax functions
    def __repr__(self):
        return (f" CPA: {self.cpa} Client name: {self.client_first_name} {self.client_last_name}"
                f" Client filling Status: {self.client_tax_filled} Time tax's filled: {self.filling_timestamp}")
