# SQL functions for database


# SQL tables
CLIENT_TABLE = """CREATE TABLE IF NOT EXISTS client
(client_id SERIAL PRIMARY KEY, 
first_name VARCHAR(10), 
last_name VARCHAR(10), 
address VARCHAR(25), 
income INTEGER, 
tax_material TEXT, 
tax_filled BOOL, 
filling_timestamp TIMESTAMP, 
cpa VARCHAR(25),
CONSTRAINT check_income_range CHECK (income >=0 AND income <= 10000000)
);"""

CPA_TABLE = """CREATE TABLE IF NOT EXISTS cpa
(cpa_id SERIAL PRIMARY KEY, 
name VARCHAR(25), 
assistant VARCHAR(25),
cpa_check BOOL
);"""


TAX_TABLE = """CREATE TABLE tax AS SELECT 
client.client_id AS client_id, 
client.first_name AS client_first_name, 
client.last_name AS client_last_name,
client.address AS client_address, 
client.income AS client_income, 
client.tax_material AS client_tax_material, 
client.tax_filled AS client_tax_filled, 
client.filling_timestamp AS filling_timestamp, 
client.cpa AS cpa 
FROM client
JOIN cpa ON client.cpa = cpa.name
AND cpa ON ;"""


# CLIENT QUERIES
INSERT_CLIENT = """INSERT INTO client(first_name, last_name, address, income,
tax_material, tax_filled, filling_timestamp, cpa) 
VALUES(%s,%s,%s,%s,%s,%s,%s,%s) RETURNING client_id"""
UPDATE_CLIENT_FILE = """UPDATE client SET first_name = %s, last_name = %s, address = %s, income = %s,
tax_material = %s, tax_filled = %s, filling_timestamp = %s, cpa = %s WHERE client_id = %s;"""
SELECT_CLIENT_BY_ID = """SELECT first_name, last_name, address, income, tax_material, tax_filled, filling_timestamp, cpa
FROM client WHERE client_id = %s;"""
VIEW_CLIENT_LIST = """SELECT * FROM client;"""
VIEW_MISSING_MATERIAL = """SELECT * FROM client WHERE tax_filled = false;"""


# CPA QUERIES
INSERT_CPA = """INSERT INTO cpa(name, assistant, cpa_check) VALUES(%s,%s,%s) RETURNING cpa_id;"""
SELECT_CPA_BY_ID = """SELECT name, assistant, cpa_check FROM cpa WHERE cpa_id = %s;"""
UPDATE_CPA_FILE = """UPDATE cpa SET name = %s, assistant = %s  WHERE cpa_id = %s;"""
UPDATE_CPA_CHECK = """UPDATE cpa SET cpa_check = %s WHERE cpa_id = %s;"""
VIEW_CPA_LIST = """SELECT * FROM cpa;"""


# TAX QUERIES
SELECT_CLIENT_TAX_LIST = """SELECT cpa, client_first_name, client_last_name, client_tax_filled, filling_timestamp 
FROM tax where client_id = %s;"""


# New User QUERIES
DATABASE_PROMPT = """
Welcome to the CPA Application

Please provide a URI to a Postgres SQL database server: """
API_PROMPT = """Please provide an API key: """
SETUP_PROMPT = """Thanks! Setting up..."""
