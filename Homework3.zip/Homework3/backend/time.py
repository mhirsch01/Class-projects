import datetime
# DATE FUNCTION


def tax_filling_timestamp():
    date = datetime.datetime.utcnow()
    user_date = date.strftime("%Y-%m-%d")
    return user_date
