# used to either connect a new user to the database or load the database
import os
from contextlib import contextmanager
from psycopg2.pool import SimpleConnectionPool
from dotenv import load_dotenv
from backend import queries


# --- New User Functions ---

def new_user_setup():
    database_uri = input(queries.DATABASE_PROMPT)
    api_key = input(queries.API_PROMPT)
    print(queries.SETUP_PROMPT)
    create_new_env_file(database_uri, api_key)


def create_new_env_file(database_uri, api_key):
    with open(".env", "w") as environ_file:
        environ_file.write(f"DATABASE_URI={database_uri}\nMAIN_API_KEY={api_key}")


load_dotenv()
if "DATABASE_URI" not in os.environ:
    new_user_setup()
    load_dotenv()

# Connection function

database_uri = os.environ["DATABASE_URI"]
pool = SimpleConnectionPool(minconn=1, maxconn=10, dsn=database_uri)


@contextmanager
def get_connection():
    conn = pool.getconn()
    try:
        yield conn
    finally:
        pool.putconn(conn)

