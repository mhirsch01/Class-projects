# This file connects the queries file to python functions for my classes
from contextlib import contextmanager
from backend import queries


@contextmanager
def get_cursor(conn):
    with conn:
        cursor = conn.cursor()
    try:
        yield cursor
    finally:
        cursor.close()


def create_tables(conn):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.CPA_TABLE)
        cursor.execute(queries.CLIENT_TABLE)


# CLIENT FUNCTIONS


def add_client(conn, first_name, last_name, address, income, tax_material, tax_filled, filling_timestamp, cpa):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.INSERT_CLIENT, (first_name, last_name, address, income, tax_material, tax_filled,
                                               filling_timestamp, cpa))
        cursor.fetchone()
        conn.commit()


def update_client(conn, client_id, first_name, last_name, address, income, tax_material, tax_filled, filling_timestamp,
                  cpa):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.UPDATE_CLIENT_FILE, (client_id, first_name, last_name, address, income, tax_material,
                                                    tax_filled, filling_timestamp, cpa))
        conn.commit()


def select_client(conn, client_id):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.SELECT_CLIENT_BY_ID, (client_id, ))
        return cursor.fetchone()


def get_missing_tax_material(conn):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.VIEW_MISSING_MATERIAL)
        client_data = cursor.fetchall()
        return client_data


def view_client_list(conn):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.VIEW_CLIENT_LIST)
        client_data = cursor.fetchall()
        return client_data

# CPA FUNCTIONS


def add_cpa(conn, name, assistant, cpa_check):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.INSERT_CPA, (name, assistant, cpa_check))
        cursor.fetchone()
        conn.commit()


def update_cpa(conn, cpa_id, new_name, new_assistant):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.UPDATE_CPA_FILE, (cpa_id, new_name, new_assistant))
        conn.commit()


def update_cpa_check(conn, cpa_check):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.UPDATE_CPA_CHECK, (cpa_check, ))
        conn.commit()


def select_cpa(conn, cpa_id):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.SELECT_CPA_BY_ID, (cpa_id, ))
        return cursor.fetchone()


def view_cpa_list(conn):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.VIEW_CPA_LIST)
        cpa_data = cursor.fetchall()
        return cpa_data


# TAX FUNCTIONS
def select_tax(conn, client_id):
    with get_cursor(conn) as cursor:
        cursor.execute(queries.SELECT_CLIENT_TAX_LIST, (client_id, ))
        return cursor.fetchone()
