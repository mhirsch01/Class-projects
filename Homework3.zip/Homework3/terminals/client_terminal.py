# Prompts for client functions
import classes.client
from backend import time


def tax_filled_prompt():
    print('Were Tax forums Submitted: ')
    tax_input = input('1. Yes 2. No SELECT: ')
    if tax_input == '2':
        return False
    elif tax_input == '1':
        return True
    else:
        print('Invalid Input')


def add_client():
    first_name = input('Clients first name: ')
    last_name = input('Clients last name: ')
    address_input = input('Clients Address: ')
    income_input = input('Enter your annual salary: ')
    tax_input = input('Tax: ')
    tax_filled = tax_filled_prompt()
    filling_timestamp = time.tax_filling_timestamp()
    cpa_name = input('Clients Cpa: ')
    insert_new_client = classes.client.Client.add_client(first_name, last_name, address_input, income_input,
                                                         tax_input, tax_filled, filling_timestamp, cpa_name)
    insert_new_client.save()


def update_client():
    client_id = input('Enter in a Client ID: ')
    client_instance = classes.client.Client.get_client_by_id(client_id)
    print(client_instance)

    if not client_instance:
        print("Client not found.")
        return

    selection = input("1 First name 2.Last name 3.Clients Address 4.Clients Salary 5.Update Clients Address 6.CPA "
                      "SELECT: ")

    if selection == '1':
        update_first = input("Client's First name: ")
        client_instance.update_client(first_name=update_first)
    elif selection == '2':
        update_last = input("Client's Last name: ")
        client_instance.update_client(last_name=update_last)
    elif selection == '3':
        update_address = input("Client's Address: ")
        client_instance.update_client(address=update_address)
    elif selection == '4':
        update_salary = input("Client's Salary: ")
        client_instance.update_client(income=update_salary)
    elif selection == '5':
        update_tax_material = input('Enter in Tax material: ')
        client_instance.update_client(tax_material=update_tax_material)
    elif selection == '6':
        update_cpa = input("Enter new CPA: ")
        client_instance.update_client(cpa=update_cpa)
    else:
        print('Invalid Input')

    client_instance.save()


def prompt_modify_client():
    question = input('1.New client 2.Update client information 3.Return SELECT: ')
    if question == '1':
        add_client()
    elif question == '2':
        update_client()
    elif question == '3':
        print('Returning to menu')
    else:
        print('Invalid Input')


def prompt_filling_process():
    tax_material = classes.client.Client.get_missing_tax_material()
    print(tax_material)


def view_all_clients():
    clients = classes.client.Client.get_all_clients()
    print(clients)


prompt_client_menu = """
Client Terminal
1. Add/Modify Client Information
2. Clients Missing Tax material
3. View all Clients
4. Exit
SELECT: 
"""

CLIENT_MENU = {
    "1.": prompt_modify_client,
    "2.": prompt_filling_process,
    "3.": view_all_clients
}


def client_menu_options():
    while (user_input := input(prompt_client_menu)) != '4':
        if user_input == '1':
            prompt_modify_client()
        elif user_input == '2':
            prompt_filling_process()
        elif user_input == '3':
            view_all_clients()
        elif user_input == '4':
            break
        else:
            print('Invalid Input')
