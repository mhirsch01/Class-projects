# Interface required:
# Check if client has provided the required materials
# Mark if tax return has been filled
# Mark if CPA checked a return
# Check if a CPA checked a return

from backend import database, connection
from terminals import cpa_terminal, client_terminal, tax_terminal
from dotenv import load_dotenv


MAIN_MENU = """
WELCOME USER
1. Client Info
2. CPA Info
3. View Taxes
4. Exit
SELECT: 
"""

load_dotenv()


def main_menu():
    with connection.get_connection() as conn:
        database.create_tables(conn)

    while (user_input := input(MAIN_MENU)) != '4':
        if user_input == '1':
            client_terminal.client_menu_options()
        elif user_input == '2':
            cpa_terminal.cpa_menu_options()
        elif user_input == '3':
            tax_terminal.tax_menu_options()
        elif user_input == '4':
            break
        else:
            print('INVALID INPUT')


if __name__ == '__main__':
    main_menu()
