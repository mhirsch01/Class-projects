# Tax terminal is meant for the user to update information based on the individual CPA
import classes.tax


def prompt_cpa_tax_list():
    retrieve_info = input('Please Enter a CPA ID: ')
    tax_material_instance = classes.tax.Tax.get_client_tax_by_(retrieve_info)
    print(tax_material_instance)


prompt_tax_menu = """
Tax Information Terminal
1. View clients tax information
2. Exit
SELECT: 
"""

TAX_MENU = {
    "1.": prompt_cpa_tax_list,
}


def tax_menu_options():
    while (user_input := input(prompt_tax_menu)) != '4':
        if user_input == '1':
            prompt_cpa_tax_list()
        elif user_input == '2':
            break
        else:
            print('Invalid Input')
