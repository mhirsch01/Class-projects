# CPA  functions
import classes.cpa
CPA_MENU = """
CHOOSE A FOLLOWING OPTION
1. Modify CPA list
2. View CPA list
3. Exit
SELECT:
"""


def client_tax_check():
    print("Did you review clients tax forums?")
    tax_check = input("1. Yes 2. No SELECT: ")
    if tax_check == '1':
        return True
    elif tax_check == '2':
        return False
    else:
        print("Invalid Input")


def new_cpa():
    cpa_name = input("Enter CPAs name: ")
    cpa_assistant = input("Enter CPA's assistant: ")
    cpa_check = client_tax_check()
    insert_new_cpa = classes.cpa.Cpa.add_cpa(cpa_name, cpa_assistant, cpa_check)
    insert_new_cpa.save()


def update_cpa():
    cpa_id = input("Enter the CPA ID you want to update: ")
    cpa_instance = classes.cpa.Cpa.get_cpa_by_id(cpa_id)
    print(cpa_instance)

    if not cpa_instance:
        print("CPA not found.")
        return

    print('Select what you would like to update: ')
    selection = input("1. CPAs name 2. CPAs assistant 3. Update Tax forum check SELECT: ")

    if selection == '1':
        update_name = input("Enter the new name: ")
        cpa_instance.update_cpa(name=update_name)
    elif selection == '2':
        update_assistant = input("Enter the new assistant: ")
        cpa_instance.update_cpa(assistant=update_assistant)
    elif selection == '3':
        print("Did you check client tax forums?")
        update_check = client_tax_check()
        cpa_instance.update_check(cpa_check=update_check)
    else:
        print('Invalid Input')

    cpa_instance.save()


def prompt_modify_cpa():
    print('Is this a new CPA or Existing CPA?')
    answer = input(' 1. New CPA 2. Update CPA information 3.Exit Select:')
    if answer == '1':
        new_cpa()
    elif answer == '2':
        update_cpa()
    elif answer == '3':
        print('Exit')
    else:
        print('Invalid Input')


def view_cpa_list():
    cpa_list = classes.cpa.Cpa.get_all_cpa()
    print(cpa_list)


def cpa_menu_options():
    while (user_input := input(CPA_MENU)) != '4':
        if user_input == '1':
            prompt_modify_cpa()
        elif user_input == '2':
            view_cpa_list()
        elif user_input == '3':
            return
        else:
            print('INVALID INPUT')
